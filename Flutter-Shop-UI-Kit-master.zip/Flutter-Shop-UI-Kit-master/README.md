### Flutter Shop UI kit

If you are planning to create an e-commerce app using Flutter then this Shop UI Kit would be the perfect choice for you to make a gorgeous app for both Android & iOS.

This kit comes with more than 15 screens which contain the most common screens for your eCommerce app like Onboarding, Authentication, Homepage, product details page, Cart, user profile and more!

### Download complete UI kit [Download](https://www.patreon.com/posts/61709201)

![Preview](/preview/0.png)
![Preview](/preview/1.jpg)
![Preview](/preview/2.jpg)

### Download complete Shop UI kit [Download](https://www.patreon.com/posts/61709201)
