package com.example.stylish

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
